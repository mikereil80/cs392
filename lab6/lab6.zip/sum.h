// Michael Reilly and Travis Dengler
// I pledge my honor that I have abided by the Stevens Honor System.

#ifndef SUM_H_
#define SUM_H_

/* Function prototype */
int sum_array(int *array, const int length);

#endif
