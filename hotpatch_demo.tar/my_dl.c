#include <stdio.h>

void my_fn() {
    printf("This is the original function.\n");
}
